package it.vfsfitvnm.vimusic.enums

enum class AlbumSortBy {
    Title,
    Year,
    DateAdded
}
